import React,{useContext} from 'react'
import { VideoContext } from './../../API/ContextApi';
import Videoplayer from './Videoplayer';
import "./video.css"
import Player from './Player';

const VideoList = () => {
    let vid = useContext(VideoContext);
    let video = vid.state
    let Handlevideo = vid.Handlevideo;
 //   console.log("kdk",video);
    return (
      <section>
        <Player />
        <div id="videoBlock">
          {video.map(val => {
            return (
              <Videoplayer key={val.id} demo={val} Handlevideo={Handlevideo} />
            );
          })}
        </div>
      </section>
    );
}

export default VideoList
