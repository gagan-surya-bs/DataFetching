import React from "react";
import DatePage from "./Pages/Date/DatePage";
import Loginpage from "./Pages/login/Loginpage";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Videoplayer from "./Pages/VideoPlayer/Videoplayer";
import VideoList from "./Pages/VideoPlayer/VideoList";


const App = () => {
  return (
    <div>
      <Router>
        <Routes>
          <Route path="/" element={<Loginpage />} />
                  <Route path="/date" element={<DatePage />} />
                  <Route path="/video" element={<VideoList/>}/>
        </Routes>
      </Router>
    </div>
  );
};

export default App;
