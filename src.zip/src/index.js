import React from 'react';
import ReactDOM from 'react-dom';
import VideoContextProvider from './API/ContextApi';
import App from './App';

ReactDOM.render(
  <VideoContextProvider>
    <App />
  </VideoContextProvider>,
  document.getElementById("root")
);
